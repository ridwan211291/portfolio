# Change Log

All notable changes to `sebastianbergmann/code-unit-reverse-lookup` are documented in this file using the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## 1.0.0 - 2016-02-13

### Added

* Initial release

